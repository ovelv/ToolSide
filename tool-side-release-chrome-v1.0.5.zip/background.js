// ToolSide background（MV3，plain JS，由 manifest 直接加载，不经过打包）
// 混合架构：展开态用浏览器原生侧栏（Chrome side_panel / Firefox sidebar_action，均为 index.html），
// 收起态由 content script（inject.js）在页面右侧自绘 36px 窄栏。background 负责入口调度与开合状态广播。

// Firefox（dist-firefox/ 变体）与 Chrome 的运行时分叉：侧栏入口、截图 API、录屏可用性。
// manifest 层差异由 scripts/make-firefox-manifest.mjs 生成，本文件只做行为分叉。
const IS_FIREFOX = /firefox/i.test(navigator.userAgent);
// Firefox 原生提供 browser 命名空间（全量 API + Promise）；Chrome 148 之前只有 chrome 命名空间。
// sidebarAction / tabs.captureTab 是 Firefox 专属 API，官方只在 browser.* 下保证可用，Firefox 分支统一走 api
const api = typeof browser !== "undefined" ? browser : chrome;

const MENU_ITEMS = [
  { id: "ts-clip-add", title: "ToolSide：加入剪贴板", contexts: ["selection"], tool: "" },
  { id: "ts-translate", title: "ToolSide：翻译", contexts: ["selection"], tool: "translate" },
  { id: "ts-translate-page", title: "ToolSide：翻译整页", contexts: ["page"], tool: "translate" },
  { id: "ts-capture", title: "ToolSide：截图当前页", contexts: ["page"], tool: "" },
  { id: "ts-record", title: "ToolSide：录制当前页", contexts: ["page"], tool: "" },
  { id: "ts-color", title: "ToolSide：提取颜色", contexts: ["all"], tool: "" },
  { id: "ts-word-count", title: "ToolSide：字数统计", contexts: ["selection"], tool: "word-count" },
  { id: "ts-ai-summary", title: "ToolSide：AI 总结", contexts: ["selection"], tool: "ai-summary" },
  { id: "ts-ocr", title: "ToolSide：OCR 识别文字", contexts: ["image"], tool: "ocr" },
  { id: "ts-img-compress", title: "ToolSide：压缩图片", contexts: ["image"], tool: "img-compress" },
  { id: "ts-img-convert", title: "ToolSide：转换图片格式", contexts: ["image"], tool: "img-convert" },
  { id: "ts-save-bookmark", title: "ToolSide：收藏此页", contexts: ["page"], tool: "" },
].filter((m) => !IS_FIREFOX || m.id !== "ts-record"); // Firefox 无 tabCapture：录屏入口整体移除

// 冷启动暂存：动作发生在面板挂载前时先存，面板挂载后通过 get-pending 取走
// 形状：{ toolId?, text?, imageUrl?, translatePage?, color?, siteId?, focusSearch?, viewClips?, viewCapture?, startRecord? }
let pendingAction = null;

// 面板存活计数：面板挂载时建立长连接、关闭时断开
let panelPorts = 0;

// 截图 / 录屏中转：截图结果、录制状态、录制成品
let lastCapture = null;
let recordingTabId = null;
let recordingPaused = false;
let lastRecording = null;
// 录屏启动 handshake 期间的目标页 id（此时 recordingTabId 还没落定），供 offscreen 降级重申 streamId
let pendingRecordTabId = null;
// 区域录屏：选区时暂存裁剪矩形（视口 CSS px + 页面视口尺寸，纯 JSON），
// start-record 时带给 offscreen 的 canvas 裁剪管线
let pendingCrop = null;

chrome.runtime.onInstalled.addListener(() => {
  for (const item of MENU_ITEMS) {
    chrome.contextMenus.create({
      id: item.id,
      title: item.title,
      contexts: item.contexts,
    });
  }
  // 扩展安装/更新/刷新后，给已打开的标签页补注入窄栏，无需用户手动刷新页面
  injectAllTabs();
  // 匿名使用统计的定时上报（默认关闭，用户在设置里开启后队列才会有数据）
  chrome.alarms.create(ANALYTICS_ALARM, { periodInMinutes: 30 });
});

/** 遍历所有 http(s) 标签页，未注入悬浮栏的程序化注入（依赖 <all_urls> 宿主权限） */
function injectAllTabs() {
  chrome.tabs
    .query({})
    .then((tabs) => {
      for (const tab of tabs) {
        if (tab.id == null) continue;
        if (!/^https?:/.test(tab.url || "")) continue;
        ensureRail(tab.id);
      }
    })
    .catch(() => {});
}

/** 向所有标签页广播侧边栏开合状态，窄栏据此自显隐 */
function broadcastPanelState(open) {
  chrome.tabs
    .query({})
    .then((tabs) => {
      for (const tab of tabs) {
        if (tab.id != null) {
          chrome.tabs
            .sendMessage(tab.id, { type: "toolside:panel-state", open })
            .catch(() => {});
        }
      }
    })
    .catch(() => {});
}

/** 唤起面板：Chrome 按标签页开 sidePanel；Firefox 开全局 sidebar（需用户手势，
 *  消息回调中调用可能不构成手势而失败——Firefox 用户改点工具栏图标 / Alt+K 兜底） */
function openPanelForTab(tabId) {
  if (IS_FIREFOX) {
    api.sidebarAction.open().catch(() => {});
    return;
  }
  chrome.sidePanel.open({ tabId }).catch(() => {});
}

chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== "toolside-panel") return;
  panelPorts++;
  broadcastPanelState(true);
  port.onDisconnect.addListener(() => {
    panelPorts--;
    if (panelPorts <= 0) {
      panelPorts = 0;
      broadcastPanelState(false);
      // 面板关闭（含用户点 Chrome 自带 ×）后，给活动标签页补注入窄栏
      api.tabs.query({ active: true, lastFocusedWindow: true }).then((tabs) => {
        const id = tabs[0] && tabs[0].id;
        if (id != null) ensureRail(id);
      });
    }
  });
});

/** 向指定标签页的 content script 发消息；目标页未注入时返回 null */
function sendToTab(tabId, msg) {
  return api.tabs.sendMessage(tabId, msg).catch(() => null);
}

/** 目标页尚未注入悬浮栏（如扩展刚更新）时程序化注入；
 *  二次探活：content script 挂载期异步加载样式、监听器尚未注册，
 *  一次 ping 未回执就注入会造成并发双实例 */
function ensureRail(tabId) {
  sendToTab(tabId, { type: "toolside:ping" }).then((res) => {
    if (res && res.handled) return;
    // service worker 无 window，用全局 setTimeout
    setTimeout(() => {
      sendToTab(tabId, { type: "toolside:ping" }).then((res2) => {
        if (res2 && res2.handled) return;
        chrome.scripting
          .executeScript({ target: { tabId }, files: ["inject.js"] })
          .catch(() => {});
      });
    }, 600);
  });
}

chrome.contextMenus.onClicked.addListener((info, tab) => {
  const item = MENU_ITEMS.find((m) => m.id === info.menuItemId);
  if (!item) return;

  if (item.id === "ts-clip-add") {
    // 加入剪贴板：sidePanel.open 必须同步（手势），存储异步补写
    if (panelPorts > 0) {
      chrome.runtime
        .sendMessage({ type: "toolside:panel-action", action: { viewClips: true } })
        .catch(() => {});
    } else {
      pendingAction = { viewClips: true };
      if (tab && tab.id != null) openPanelForTab(tab.id);
    }
    const entry = {
      id: `c-${Date.now()}`,
      text: info.selectionText || "",
      title: (tab && tab.title) || "",
      url: (tab && tab.url) || "",
      at: Date.now(),
    };
    chrome.storage.local
      .get("toolside.clips")
      .then((obj) => {
        const list = Array.isArray(obj["toolside.clips"]) ? obj["toolside.clips"] : [];
        return chrome.storage.local.set({ "toolside.clips": [entry, ...list].slice(0, 100) });
      })
      .catch(() => {});
    return;
  }

  // 收藏此页：直接写入浏览器书签栏末尾，badge 短暂提示成功（不打开面板）；
  // 浏览器内置页（chrome:// 等）不可收藏，静默跳过
  if (item.id === "ts-save-bookmark") {
    if (tab && tab.url && !/^(chrome|edge|about|devtools):/i.test(tab.url)) {
      chrome.bookmarks
        .create({ parentId: "1", title: tab.title || tab.url, url: tab.url })
        .then(() => {
          chrome.action.setBadgeText({ text: "✓" });
          chrome.action.setBadgeBackgroundColor({ color: "#3B5BFD" });
          setTimeout(() => chrome.action.setBadgeText({ text: "" }), 2000);
        })
        .catch(() => {});
    }
    return;
  }

  // 截图：sidePanel.open 必须同步（手势），截图异步完成后暂存，面板自行拉取
  if (item.id === "ts-capture") {
    if (tab && tab.id != null) {
      captureVisible(tab, { format: "png" })
        .then((dataUrl) => {
          lastCapture = { dataUrl, title: tab.title || "", url: tab.url || "", at: Date.now() };
        })
        .catch(() => {});
    }
    dispatchAction({ viewCapture: true }, tab);
    return;
  }

  // 录屏：再点一次停止；开始/停止都唤起面板展示状态与结果
  if (item.id === "ts-record") {
    if (recordingTabId != null) {
      stopRecording(tab).then(() => dispatchAction({ viewCapture: true }, tab));
    } else if (tab && tab.id != null) {
      startRecording(tab).then((r) => {
        if (r.ok) dispatchAction({ viewCapture: true, startRecord: true }, tab);
      });
    }
    return;
  }

  // 提取颜色：content script 在右键坐标处取元素计算色值
  if (item.id === "ts-color") {
    if (tab && tab.id != null) {
      sendToTab(tab.id, { type: "toolside:extract-color", x: info.x, y: info.y }).then((res) => {
        dispatchAction({ toolId: "color-picker", color: (res && res.color) || "" }, tab);
      });
    }
    return;
  }

  const payload = {
    toolId: item.tool,
    text: info.selectionText || "",
    imageUrl: info.srcUrl || "",
    // 「翻译整页」：面板打开后自行抓取页面正文翻译
    translatePage: item.id === "ts-translate-page" || undefined,
    at: Date.now(),
  };
  dispatchAction(payload, tab);
});

/** 面板已挂载则热推动作；否则暂存 pendingAction 并同步唤起原生侧边栏（菜单点击是用户手势） */
function dispatchAction(payload, tab) {
  if (panelPorts > 0) {
    chrome.runtime
      .sendMessage({ type: "toolside:panel-action", action: payload })
      .then((res) => {
        if (!res || !res.handled) pendingAction = payload;
      })
      .catch(() => {
        pendingAction = payload;
      });
  } else {
    pendingAction = payload;
    if (tab && tab.id != null) openPanelForTab(tab.id);
  }
}

/** 把 tabCapture / offscreen 的报错翻译成人话，避免“未生效”时用户一头雾水 */
function describeCaptureError(e) {
  const msg = String((e && e.message) || e || "");
  if (/activeTab|permission|not granted|access|denied/i.test(msg)) {
    return "未获得标签页捕获权限：请先点一下扩展图标或右键菜单再试";
  }
  return msg || "标签页捕获失败（可能是受限页面）";
}

/** 可视区截图：Chrome 用 captureVisibleTab(windowId)，Firefox 用 captureTab（首参数是 tabId，见 MDN） */
function captureVisible(tab, opts) {
  if (IS_FIREFOX) return api.tabs.captureTab(tab.id, opts);
  return api.tabs.captureVisibleTab(tab.windowId, opts);
}

/** captureVisibleTab 有约 2 次/秒的全局配额：撞限后等一个配额周期，原地重试一次 */
async function captureWithBackoff(tab) {
  try {
    return await captureVisible(tab, { format: "png" });
  } catch (e) {
    await new Promise((r) => setTimeout(r, 1100));
    return captureVisible(tab, { format: "png" });
  }
}

/** 开始录屏：申请 tab 媒体流 → 确保 offscreen 文档存活 → 启动 MediaRecorder
 *  cropRect：区域录屏的裁剪矩形（{x,y,w,h,dpr,viewW,viewH}），整页录制时为空 */
async function startRecording(tab, cropRect) {
  try {
    const streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tab.id });
    if (!(await hasOffscreen())) {
      await chrome.offscreen.createDocument({
        url: "offscreen.html",
        reasons: ["USER_MEDIA"],
        justification: "录制当前标签页画面与声音",
      });
    }
    pendingRecordTabId = tab.id;
    let res;
    try {
      res = await chrome.runtime.sendMessage({
        type: "toolside:offscreen-start-record",
        streamId,
        cropRect: cropRect || undefined,
      });
    } catch (e) {
      // offscreen 偶发重启等异常：退化为整标签页录制重试（streamId 未被消费，可复用）
      res = await chrome.runtime.sendMessage({
        type: "toolside:offscreen-start-record",
        streamId,
      });
    }
    pendingRecordTabId = null;
    // 区域裁剪是否生效（offscreen 回执）：把 cropped 传回面板提示用户
    const usedCrop = !!(cropRect && res && res.ok && res.cropped);
    if (res && res.ok) {
      recordingTabId = tab.id;
      recordingPaused = false;
      // 同步进 session 存储：5 分钟长录制中 MV3 service worker 可能被回收重启，
      // 内存里的 recordingTabId 会丢——自动停止推送进来时靠它兜底找回标签页
      void chrome.storage.session?.set({ toolsideRecordingTabId: tab.id }).catch?.(() => {});
      // 选区标记外扩 6px（见 content 脚本），虚线完全在采样窗外，录制全程常显
      // 帮用户确认录制范围；结束后由 clearCropMarkerAndReset 收掉
      return { ok: true, cropped: usedCrop };
    }
    sendToTab(tab.id, { type: "toolside:clear-crop-marker" });
    return { ok: false, error: (res && res.error) || "offscreen 启动录制失败" };
  } catch (e) {
    pendingRecordTabId = null;
    sendToTab(tab.id, { type: "toolside:clear-crop-marker" });
    // 受限页面 / 无音频轨道 / 未授权等都会走到这里，把原因透传给面板
    return { ok: false, error: describeCaptureError(e) };
  }
}

/** 录制标签页 id：内存优先，session 存储兜底（service worker 中途被回收重启时，
 *  内存变量丢失，仍能从 storage.session 找回，保证结束清除消息能送达页面） */
async function resolveRecordingTabId() {
  if (recordingTabId != null) return recordingTabId;
  try {
    const v = await chrome.storage.session.get("toolsideRecordingTabId");
    return v?.toolsideRecordingTabId ?? null;
  } catch (e) {
    return null;
  }
}

/** 录制结束后通知页面收掉选区标记并复位录制状态（含 worker 重启后的兜底） */
async function clearCropMarkerAndReset() {
  const tid = await resolveRecordingTabId();
  if (tid != null) sendToTab(tid, { type: "toolside:clear-crop-marker" });
  recordingTabId = null;
  recordingPaused = false;
  void chrome.storage.session?.remove("toolsideRecordingTabId").catch?.(() => {});
}

async function stopRecording() {
  // 收掉页面上的选区标记（区域录屏时显示的虚线框）
  await clearCropMarkerAndReset();
  pendingCrop = null;
  try {
    const res = await chrome.runtime.sendMessage({ type: "toolside:offscreen-stop-record" });
    // 失败结果（编码器异常 / 内容过短）也存下来，面板收割时能看到具体原因
    if (res && typeof res.ok === "boolean") lastRecording = res;
  } catch (e) {
    // offscreen 已销毁等异常：忽略
  }
}

async function pauseRecording() {
  if (recordingTabId == null) return false;
  try {
    const res = await chrome.runtime.sendMessage({ type: "toolside:offscreen-pause-record" });
    if (res && res.ok) {
      recordingPaused = true;
      return true;
    }
  } catch (e) {}
  return false;
}

async function resumeRecording() {
  if (recordingTabId == null) return false;
  try {
    const res = await chrome.runtime.sendMessage({ type: "toolside:offscreen-resume-record" });
    if (res && res.ok) {
      recordingPaused = false;
      return true;
    }
  } catch (e) {}
  return false;
}

async function hasOffscreen() {
  try {
    return await chrome.offscreen.hasDocument();
  } catch (e) {
    return false;
  }
}

// 点击工具栏图标 / 快捷键 Alt+K：面板开着则关闭（窄栏接管），否则同步唤起
chrome.action.onClicked.addListener((tab) => {
  if (panelPorts > 0) {
    if (IS_FIREFOX) {
      // Firefox 侧栏页面收不到 window.close()（脚本不能关侧栏），直接关常驻侧栏
      api.sidebarAction.close().catch(() => {});
    } else {
      chrome.runtime.sendMessage({ type: "toolside:close-panel" }).catch(() => {});
    }
    if (tab && tab.id != null) ensureRail(tab.id);
    return;
  }
  if (tab && tab.id != null) {
    openPanelForTab(tab.id);
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg.type !== "string") return false;

  if (msg.type === "toolside:open-panel") {
    // 悬浮栏 dock 点击：Chrome 借消息回调直接唤起原生面板；Firefox 走页面内 iframe 面板（见下）
    const action = {
      toolId: msg.toolId || undefined,
      siteId: msg.siteId || undefined,
      focusSearch: !!msg.focusSearch || undefined,
    };
    const hasAction = action.toolId || action.siteId || action.focusSearch;
    if (panelPorts > 0) {
      // 面板已开（dock 正常隐藏，兼作兑底）：直接热推动作
      if (hasAction) {
        chrome.runtime.sendMessage({ type: "toolside:panel-action", action }).catch(() => {});
      }
    } else {
      if (hasAction) pendingAction = { ...(pendingAction || {}), ...action };
      // Firefox：消息回调不构成手势，sidebarAction.open() 必被拒——页面内 iframe 面板
      // 由 inject 就地展开（见 EmbedPanel），这里只记 pendingAction 供 iframe 面板冷启动拉取
      const tabId = sender.tab && sender.tab.id;
      if (!IS_FIREFOX && tabId != null) openPanelForTab(tabId);
    }
    sendResponse({ ok: true });
    return false;
  }

  if (msg.type === "toolside:is-panel-open") {
    sendResponse({ open: panelPorts > 0 });
    return false;
  }

  if (msg.type === "toolside:get-pending") {
    const action = pendingAction;
    pendingAction = null;
    sendResponse(action);
    return false;
  }

  // 截图：右键触发时暂存的结果（取走即清）
  if (msg.type === "toolside:get-capture") {
    sendResponse(lastCapture);
    lastCapture = null;
    return false;
  }

  // 截图：面板内手动按钮，即拍即回（可视区域）
  if (msg.type === "toolside:request-capture") {
    chrome.tabs
      .query({ active: true, lastFocusedWindow: true })
      .then((tabs) => {
        const tab = tabs[0];
        if (!tab || tab.id == null) return sendResponse(null);
        return captureVisible(tab, { format: "png" }).then((dataUrl) =>
          sendResponse({ dataUrl, title: tab.title || "", url: tab.url || "", at: Date.now() }),
        );
      })
      .catch(() => sendResponse(null));
    return true;
  }

  // 区域截图：内容脚本拉选区遮罩，选中后隐藏遮罩再捕获可视区，返回裁剪矩形给面板裁剪（反馈 #2）
  // 失败统一返回 { failed, error } 透传原因；仅用户主动取消返回 null（面板静默不提示）
  if (msg.type === "toolside:request-capture-region") {
    chrome.tabs
      .query({ active: true, lastFocusedWindow: true })
      .then(async (tabs) => {
        const tab = tabs[0];
        if (!tab || tab.id == null || tab.windowId == null)
          return sendResponse({ failed: true, error: "未找到活动标签页" });
        const sel = await sendToTab(tab.id, { type: "toolside:select-region" });
        if (sel && sel.ok === false) return sendResponse(null); // 用户 Esc / 空选取消
        if (!sel || !sel.rect)
          return sendResponse({ failed: true, error: "该页面不支持区域选择（可能是受限页面）" });
        // 遮罩已隐藏，稍等一帧再捕获，避免拍到遮罩残影
        await new Promise((r) => setTimeout(r, 160));
        try {
          const dataUrl = await captureWithBackoff(tab);
          sendResponse({
            dataUrl,
            title: tab.title || "",
            url: tab.url || "",
            at: Date.now(),
            rect: sel.rect,
            dpr: sel.dpr || 1,
          });
        } catch (e) {
          sendResponse({ failed: true, error: describeCaptureError(e) });
        }
      })
      .catch((e) => sendResponse({ failed: true, error: describeCaptureError(e) }));
    return true;
  }

  // 整页截图：从顶部逐屏滚动 + captureVisibleTab，收集各屏图片与纵向偏移，由面板拼接（反馈 #2）
  // 失败统一返回 { failed, error } 透传原因；成功携带 truncated 标记是否因超长截断
  if (msg.type === "toolside:request-capture-full") {
    const SHOT_GAP_MS = 600; // captureVisibleTab 配额约 2 次/秒，间隔必须 ≥500ms 才稳定（并发退避兜底其余场景）
    const MAX_SHOTS = 20; // 超长页最多逐屏捕获 20 屏，防止内存膨胀与分钟级等待
    chrome.tabs
      .query({ active: true, lastFocusedWindow: true })
      .then(async (tabs) => {
        const tab = tabs[0];
        if (!tab || tab.id == null || tab.windowId == null)
          return sendResponse({ failed: true, error: "未找到活动标签页" });
        let info = null;
        let response;
        try {
          info = await sendToTab(tab.id, { type: "toolside:page-info" });
          if (!info) {
            response = { failed: true, error: "无法读取页面信息（可能是受限页面）" };
          } else {
            const vh = Math.max(info.innerHeight || 0, 1);
            const sh = Math.max(info.scrollHeight || 0, vh);
            const sw = Math.max(info.scrollWidth || 0, info.innerWidth || 0);
            const dpr = info.dpr || 1;
            const startY = info.scrollY || 0;
            const shots = [];
            let y = 0;
            let covered = 0;
            while (y < sh) {
              // 最后一屏对齐页面底部，避免拍到页面外空白；其余屏按视口高度步进
              const targetY = Math.max(0, Math.min(y, sh - vh));
              const pos = await sendToTab(tab.id, { type: "toolside:set-scroll", x: 0, y: targetY });
              await new Promise((r) => setTimeout(r, SHOT_GAP_MS)); // 守住配额间隔，兼顾渲染 / 懒加载
              const dataUrl = await captureWithBackoff(tab);
              const realY = pos && typeof pos.scrollY === "number" ? pos.scrollY : targetY;
              shots.push({ dataUrl, y: realY });
              covered = targetY + vh;
              if (covered >= sh) break; // 已到底部（含对齐底屏）
              if (shots.length >= MAX_SHOTS) break; // 超长页面截断，height 同步收缩避免拼接出大片空白
              y += vh;
            }
            response = {
              shots,
              width: sw,
              height: Math.min(sh, covered),
              truncated: covered < sh,
              dpr,
              title: tab.title || "",
              url: tab.url || "",
              at: Date.now(),
            };
          }
        } catch (e) {
          response = { failed: true, error: describeCaptureError(e) };
        } finally {
          // 无论成败都把用户的滚动位置还原回去（失败时不再卡在截图途中）
          const backY = info ? info.scrollY || 0 : 0;
          await sendToTab(tab.id, { type: "toolside:set-scroll", x: 0, y: backY });
        }
        sendResponse(response);
      })
      .catch((e) => sendResponse({ failed: true, error: describeCaptureError(e) }));
    return true;
  }

  if (msg.type === "toolside:record-state") {
    sendResponse({ recording: recordingTabId != null, paused: recordingPaused });
    return false;
  }

  // offscreen 音频轨道获取失败后的降级重试：streamId 为一次性凭证，必须重新申领新的再用
  if (msg.type === "toolside:offscreen-new-stream") {
    (async () => {
      try {
        const tid = recordingTabId != null ? recordingTabId : pendingRecordTabId;
        if (tid == null) return sendResponse({});
        const streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tid });
        sendResponse({ streamId });
      } catch (e) {
        sendResponse({});
      }
    })();
    return true;
  }

  // 区域录屏：让页面拉选区并画上选区标记；矩形返回面板展示，
  // 裁剪矩形暂存 pendingCrop，待 start-record 时一并下发
  if (msg.type === "toolside:request-record-region") {
    chrome.tabs
      .query({ active: true, lastFocusedWindow: true })
      .then(async (tabs) => {
        const tab = tabs[0];
        if (!tab || tab.id == null)
          return sendResponse({ failed: true, error: "未找到活动标签页" });
        const sel = await sendToTab(tab.id, { type: "toolside:select-region", wantCrop: true });
        if (sel && sel.ok === false) return sendResponse(null); // 用户 Esc / 空选取消
        if (!sel || !sel.rect)
          return sendResponse({ failed: true, error: "该页面不支持区域选择（可能是受限页面）" });
        pendingCrop = {
          tabId: tab.id,
          rect: {
            ...sel.rect,
            dpr: sel.dpr || 1,
            viewW: sel.viewW || 0,
            viewH: sel.viewH || 0,
          },
        };
        sendResponse({ rect: sel.rect, dpr: sel.dpr || 1 });
      })
      .catch((e) => sendResponse({ failed: true, error: describeCaptureError(e) }));
    return true;
  }

  // 面板内「开始录屏」按钮：对当前活动标签页发起，并把失败原因透传给面板
  if (msg.type === "toolside:start-record") {
    chrome.tabs
      .query({ active: true, lastFocusedWindow: true })
      .then((tabs) => {
        const tab = tabs[0];
        if (!tab || tab.id == null) return sendResponse({ ok: false, error: "未找到活动标签页" });
        let cropRect;
        if (msg.region) {
          if (!pendingCrop || pendingCrop.tabId !== tab.id)
            return sendResponse({ ok: false, error: "未获取到录制区域，请重新选择" });
          cropRect = pendingCrop.rect;
          pendingCrop = null;
        }
        return startRecording(tab, cropRect).then((r) => sendResponse(r));
      })
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (msg.type === "toolside:stop-record") {
    stopRecording().then(() => sendResponse({ ok: true }));
    return true;
  }

  if (msg.type === "toolside:pause-record") {
    pauseRecording().then((ok) => sendResponse({ ok }));
    return true;
  }

  if (msg.type === "toolside:resume-record") {
    resumeRecording().then((ok) => sendResponse({ ok }));
    return true;
  }

  // 录屏成品：取走即清（成品实体在 OPFS，这里只暂存文件名元数据，消息通道无大载荷）
  if (msg.type === "toolside:get-recording") {
    sendResponse(lastRecording);
    lastRecording = null;
    return false;
  }

  // offscreen 录制期心跳：消息本身即重置 SW 空闲计时器，防止录制中被回收丢状态
  if (msg.type === "toolside:offscreen-keepalive") {
    sendResponse({ ok: true });
    return false;
  }

  // offscreen 到达时长上限自动停止后主动推来
  if (msg.type === "toolside:offscreen-recording") {
    // fire-and-forget：清除标记要走 session 存储兜底（worker 可能已重启丢内存态），
    // 不阻塞回执
    void clearCropMarkerAndReset();
    // 成败都暂存：面板轮询收割时能看到「内容过短 / 编码器异常」等具体原因
    if (msg.recording) lastRecording = msg.recording;
    sendResponse({ ok: true });
    return false;
  }

  return false;
});

// ===== 匿名使用统计：定时上报（队列由面板/悬浮栏写入，逻辑同 src/lib/toolside/analytics.ts）=====
// 路径前缀不带 /api/：nginx 对 /api/ 路径有拦截规则，对外暴露绕开
const ANALYTICS_ENDPOINT = "https://jiandan.link/toolside/events";
const ANALYTICS_ALARM = "toolside-analytics-flush";

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ANALYTICS_ALARM) flushAnalyticsQueue();
});

async function flushAnalyticsQueue() {
  let queue = null;
  try {
    const obj = await chrome.storage.local.get([
      "toolside.settings",
      "toolside.analytics.queue",
      "toolside.analytics.clientId",
      "toolside.auth",
    ]);
    const settings = obj["toolside.settings"];
    if (!settings || !settings.analytics) return; // 用户未开启统计：不动队列
    queue = obj["toolside.analytics.queue"];
    if (!Array.isArray(queue) || !queue.length) return;
    let client_id = obj["toolside.analytics.clientId"];
    if (!client_id) {
      client_id = crypto.randomUUID();
      await chrome.storage.local.set({ "toolside.analytics.clientId": client_id });
    }
    // 取空再发，失败还回（与期间新增合并）；与面板内 flush 并发时可能重复上报少量事件，统计场景可接受
    await chrome.storage.local.set({ "toolside.analytics.queue": [] });
    const auth = obj["toolside.auth"];
    const user_id = auth && auth.user && auth.user.user_id ? String(auth.user.user_id) : "";
    const res = await fetch(ANALYTICS_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        client_id,
        user_id,
        ext_version: chrome.runtime.getManifest().version,
        events: queue,
      }),
    });
    if (!res.ok) throw new Error("http " + res.status);
  } catch (e) {
    // 还回队列（新入队的排后面），截断到上限，等下轮再试
    if (Array.isArray(queue) && queue.length) {
      try {
        const obj = await chrome.storage.local.get("toolside.analytics.queue");
        const cur = Array.isArray(obj["toolside.analytics.queue"]) ? obj["toolside.analytics.queue"] : [];
        await chrome.storage.local.set({ "toolside.analytics.queue": [...queue, ...cur].slice(-300) });
      } catch (e2) {}
    }
  }
}
