// ToolSide offscreen document：MV3 service worker 无法调 getUserMedia，
// 标签页录屏在这里完成（chrome.tabCapture streamId → MediaRecorder → 视频）。
// 录完的成品写入扩展 origin 共享的 OPFS，runtime 消息只回传文件名等元数据：
// 消息通道按 JSON 序列化，以前走 base64 字符串时一份视频会在内存里滚出
// 8~10 份副本（高分屏录 2 分半峰值破 1GB），渲染进程 OOM 直接崩浏览器。

const MAX_MS = 5 * 60 * 1000; // 最长录 5 分钟，避免内存膨胀

const REC_FILE_PREFIX = "toolside-record-"; // 录制成品在 OPFS 根目录的文件名前缀

/** 拿扩展 origin 共享的 OPFS 根目录（offscreen / side panel / SW 同 origin 可见） */
function opfsRoot() {
  return navigator.storage.getDirectory();
}

/** 清理 OPFS 里的历史录制文件（上次会话未被面板收割的孤儿），防止磁盘无限累积。
 *  任何失败都吞掉：清理只是保洁，不能阻塞录制 */
async function cleanOldRecordings() {
  try {
    const root = await opfsRoot();
    const stale = [];
    for await (const name of root.keys()) {
      if (typeof name === "string" && name.startsWith(REC_FILE_PREFIX)) stale.push(name);
    }
    for (const name of stale) {
      try {
        await root.removeEntry(name);
      } catch (e) {}
    }
  } catch (e) {}
}

/** 成品 Blob 落盘 OPFS：写入是流式的，内存只瞬时持有这一份 Blob；
 *  返回文件名，面板按名 getFile() 直读（零拷贝过消息通道） */
async function saveToOPFS(blob, mime) {
  const root = await opfsRoot();
  const ext = mime.includes("mp4") ? "mp4" : "webm";
  const name = `${REC_FILE_PREFIX}${Date.now()}.${ext}`;
  const fh = await root.getFileHandle(name, { create: true });
  const w = await fh.createWritable();
  await w.write(blob);
  await w.close();
  return name;
}

let recorder = null;
let chunks = [];
let audioCtx = null; // 标签页声音外放：Audio 元素在 offscreen 里受自动播放策略限制，用 AudioContext 直连
let maxTimer = null;
let keepaliveTimer = null;
let recordError = null; // MediaRecorder onerror 的原因，stop 时透传给面板
let recordStartedAt = 0; // 正式录制开始时刻（Date.now），stop 时换算 Duration 写入 WebM
let cropped = false; // 本次录制是否在裁剪选区（canvas 路径）
let liveTracks = []; // 本次会话申领的全部轨道，stop 时统一关闭（纯画面降级录制的音轨不在 recorder.stream 里）
let cropTimer = null; // 裁剪绘制循环的定时器（rVFC 不可用 / 探测失败回退时使用）
let cropRafId = 0; // rVFC 帧驱动循环句柄
let cropWatchdog = null; // rVFC 可用性探测定时（2s 窗口后决策驱动方式）
let cropDraw = null; // 裁剪单帧绘制函数（buildCropper 闭包内生成，供循环调用）
let cropVideo = null; // 裁剪管线的视频解码载体（muted，仅供 drawImage 取帧）

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.type === "toolside:offscreen-start-record") {
    start(String(msg.streamId || ""), msg.cropRect || null)
      .then(() => sendResponse({ ok: true, cropped }))
      .catch((e) => sendResponse({ ok: false, error: String((e && e.message) || e) }));
    return true;
  }
  if (msg && msg.type === "toolside:offscreen-stop-record") {
    stop()
      .then((r) => sendResponse(r))
      .catch((e) => sendResponse({ ok: false, error: String((e && e.message) || e) }));
    return true;
  }
  if (msg && msg.type === "toolside:offscreen-pause-record") {
    try {
      if (wcSession) {
        // WebCodecs 路径：暂停时 draw 钩子/音频循环自行跳帧（不产数据）
        wcSession.paused = true;
        return sendResponse({ ok: true });
      }
      if (recorder && recorder.state === "recording") {
        recorder.pause();
        return sendResponse({ ok: true });
      }
      sendResponse({ ok: false });
    } catch (e) {
      sendResponse({ ok: false });
    }
    return false;
  }
  if (msg && msg.type === "toolside:offscreen-resume-record") {
    try {
      if (wcSession) {
        // 恢复编码（暂停期间的 PTS 间隙是预期语义，见 cropFrameSink 注释）
        wcSession.paused = false;
        return sendResponse({ ok: true });
      }
      if (recorder && recorder.state === "paused") {
        recorder.resume();
        return sendResponse({ ok: true });
      }
      sendResponse({ ok: false });
    } catch (e) {
      sendResponse({ ok: false });
    }
    return false;
  }
  return false;
});

/** 音频降级重试时向背景重新申领 streamId（streamId 是一次性凭证，不能复用） */
async function newStreamId() {
  try {
    const res = await chrome.runtime.sendMessage({ type: "toolside:offscreen-new-stream" });
    return (res && res.streamId) || "";
  } catch (e) {
    return "";
  }
}

/** 录制期心跳：让 background service worker 持续存活，
 *  否则 30s 空闲会被回收，录制状态与成品缓冲全部丢失 */
function setKeepalive(on) {
  if (keepaliveTimer) {
    clearInterval(keepaliveTimer);
    keepaliveTimer = null;
  }
  if (on) {
    keepaliveTimer = setInterval(() => {
      chrome.runtime.sendMessage({ type: "toolside:offscreen-keepalive" }).catch(() => {});
    }, 25000); // 小于 SW 的 30s idle 回收阈值
  }
}

async function grabStream(streamId, audio) {
  return navigator.mediaDevices.getUserMedia({
    audio: audio
      ? { mandatory: { chromeMediaSource: "tab", chromeMediaSourceId: streamId } }
      : false,
    video: {
      mandatory: {
        chromeMediaSource: "tab",
        chromeMediaSourceId: streamId,
        // 不限制宽高：保持页面原生分辨率，避免非 16:9 / 高分屏被缩放变形
      },
    },
  });
}

/** 用 400ms 微录制体检候选容器：有些环境 isTypeSupported 放行但编码器静默失败
 *  （只吐容器头不吐帧，产物 0 时长），只有真录一段才能提前发现并换容器。
 *  体检在裁剪前的整幅流上做，关键帧大小稳定无歧义 */
function probeMime(stream, mime) {
  return new Promise((resolve) => {
    let settled = false;
    const finish = (ok) => {
      if (settled) return;
      settled = true;
      resolve(ok);
    };
    let rec;
    try {
      rec = new MediaRecorder(stream, { mimeType: mime });
    } catch (e) {
      return finish(false);
    }
    const parts = [];
    rec.ondataavailable = (e) => {
      if (e.data && e.data.size > 0) parts.push(e.data);
    };
    rec.onstop = () => finish(parts.reduce((n, c) => n + c.size, 0) >= 2000);
    rec.onerror = () => finish(false);
    try {
      rec.start();
      setTimeout(() => {
        try {
          if (rec.state !== "inactive") rec.stop();
          else finish(false);
        } catch (e) {
          finish(false);
        }
      }, 400);
    } catch (e) {
      finish(false);
    }
    setTimeout(() => finish(false), 2000);
  });
}

/** 候选容器逐个体检（MP4 优先：H.264 播放器通吃、自带时长与索引；不行回退 WebM）。
 *  每档先试带音轨的组合，再试纯画面组合：个别环境音轨不出数据会拖死 muxer，
 *  纯画面是可靠兜底。全部失败则交由 MediaRecorder 自选默认容器。
 *  VP8 必须排在 VP9 前：无硬编时 VP9 软编速度只有输入帧率的几分之一，帧在
 *  编码器输入队列里持续积压，几分钟后把渲染/GPU 管线内存撑爆（实测录制中崩），
 *  VP8 软编速度快得多；固定码率下 VP9 的压缩优势也不重要 */
async function pickMime(withAudioStream, videoOnlyStream, hasAudio) {
  const deadline = Date.now() + 8000; // 每档体检约 0.5s，封顶 8s 防病态环境拖死启动
  for (const m of [
    "video/mp4",
    "video/mp4;codecs=avc1",
    "video/webm;codecs=vp8,opus",
    "video/webm;codecs=vp9,opus",
    "video/webm",
  ]) {
    if (!MediaRecorder.isTypeSupported(m)) continue;
    if (hasAudio && Date.now() < deadline && (await probeMime(withAudioStream, m)))
      return { mime: m, withAudio: true };
    if (Date.now() < deadline && (await probeMime(videoOnlyStream, m)))
      return { mime: m, withAudio: false };
  }
  return { mime: "", withAudio: false };
}

/** 固定视口区域裁剪（canvas 路径）：把标签页捕获流逐帧裁剪到选区，
 *  产出新的视频轨供 MediaRecorder 录制。
 *  不用 Element Capture 的 cropTo：它对非 self-capture 轨道（扩展 offscreen
 *  捕获其它标签页）受 RegionCaptureOfOtherTabs 开关把门（未默认启用，
 *  crbug.com/406175378），且要求在任何 MediaRecorder 消费轨道之前调用。 */
function buildCropper(videoTrack, rect) {
  // rect: { x, y, w, h, dpr, viewW, viewH } —— 选区与页面视口均为 CSS px
  const video = document.createElement("video");
  video.muted = true; // 仅作解码载体；声音由 AudioContext 外放，muted 不影响轨道数据
  video.playsInline = true;
  video.srcObject = new MediaStream([videoTrack]);
  video.play().catch(() => {});

  const canvas = document.createElement("canvas");
  // 输出物理分辨率（CSS 尺寸 × dpr）：回放 1:1 对应屏幕物理像素，不降采样。
  // 曾用纯 CSS 分辨率给 GPU/编码减压（当时录制中崩溃的主因），现在 20fps 节流
  // 已从源头稳住管线，恢复物理分辨率换回原生清晰度。面积预算钳制：超大选区
  // （如 2x 屏全屏 ≈ 830 万 px）软编追不住会再次积压，按 ≤210 万 px 等比降回
  const dprScale = Math.min(
    rect.dpr || 1,
    Math.sqrt(2100000 / Math.max(1, rect.w * rect.h)),
  );
  // 宽高向下取偶：H264 硬编要求帧宽高为偶数（YUV420 的 2×2 宏块对齐），奇数
  // 选区会让 VideoEncoder 的 isConfigSupported 全档拒绝、configure 报
  // "H264 only supports even sized frames"——曾因此静默回退 VP8 软编（模糊根因）。
  // VP8/MediaRecorder 对奇偶无要求，统一取偶两路径共用；选区边缘差 1px 视觉无差
  canvas.width = Math.max(2, Math.round(rect.w * dprScale) & ~1);
  canvas.height = Math.max(2, Math.round(rect.h * dprScale) & ~1);
  // alpha:false：视频画面全不透明，去掉 alpha 通道后 GPU 纹理带宽近乎减半，
  // 降低持续满载导致 GPU 进程崩溃/驱动复位（表现即录制中浏览器闪黑屏）的风险
  const ctx = canvas.getContext("2d", { alpha: false });

  // 视频像素尺寸 ÷ 页面视口 CSS 尺寸 = 映射比。实测（帧 1920×1080 / 视口 1534×937 / dpr 1）
  // Chrome 可能把捕获重映射到标准帧：视口等比缩放后 letterbox 居中，两轴比值不等。
  // 按此模型换算：内容原点偏移 ox/oy + 统一等比 scale = min(sx, sy)，圆不变形且位置对齐
  const draw = () => {
    const vw = video.videoWidth;
    const vh = video.videoHeight;
    if (!vw || !vh || !rect.viewW || !rect.viewH) return; // 首帧未就绪 / 缺视口尺寸
    const sx = vw / rect.viewW;
    const sy = vh / rect.viewH;
    const scale = Math.min(sx, sy);
    const ox = (vw - rect.viewW * scale) / 2;
    const oy = (vh - rect.viewH * scale) / 2;
    // 源窗口四边内缩：选区边界外那圈虚线标记（outline 贴边外侧）与坐标亚像素舍入
    // 混采样会从边缘透进画面（实测右缘可见虚线），内缩后选区外像素永不入镜；
    // 内缩量按映射比放大（物理分辨率下源像素更小，2 源像素可能不足 1 CSS 像素）
    const INSET = Math.max(2, Math.ceil(scale * 2));
    const sw = Math.max(2, rect.w * scale - INSET * 2);
    const sh = Math.max(2, rect.h * scale - INSET * 2);
    const px = Math.max(0, Math.min(ox + rect.x * scale + INSET, vw - sw));
    const py = Math.max(0, Math.min(oy + rect.y * scale + INSET, vh - sh));
    try {
      ctx.drawImage(video, px, py, sw, sh, 0, 0, canvas.width, canvas.height);
      // 帧钩子：WebCodecs 路径在每帧绘制完成后从 canvas 包装 VideoFrame 送编码器
      //（MediaRecorder 路径此钩子为 null，走 captureStream 自行取帧）
      if (cropFrameSink) cropFrameSink();
    } catch (e) {}
  };
  cropVideo = video;
  cropDraw = draw;
  // offscreen 文档不可见，rAF 不会触发；chrome-extension 源页面的 timer 不受后台节流。
  // 首帧预热：元数据未就绪时 draw 是空操作、canvas 无帧，captureStream 的轨道
  // 不产帧 → 编码器体检全挂。等首帧画出（loadeddata / 轮询 / 800ms 超时放行）再开循环。
  const ready = new Promise((resolve) => {
    let settled = false;
    const kick = () => {
      if (settled) return;
      settled = true;
      clearInterval(poll);
      clearTimeout(fallback);
      draw(); // 先画一帧再开循环，保证轨道立即可用
      startDrawLoop();
      resolve(video.videoWidth > 0);
    };
    const poll = setInterval(() => {
      if (video.videoWidth > 0) kick();
    }, 50);
    const fallback = setTimeout(kick, 800); // 事件不可靠时也开跑，不让录制初始化无限等待
    video.addEventListener("loadeddata", kick, { once: true });
  });
  // captureStream 上限 30fps：与 draw 节流一致，编码器输入 ≤ 消化能力，GPU 侧帧
  // 队列不积压（实测 29fps 输入 + VP8 软编时 GPU 进程可涨到 8.9GB）。WebCodecs
  // 路径不消费此轨道（直接从 canvas 取帧）；回退软编路径时会约束降回 20fps
  return { track: canvas.captureStream(30).getVideoTracks()[0], ready, canvas };
}

/** WebCodecs 路径的每帧回调（draw 完成后触发）。由 startWebCodecsRecording 设置，
 *  stopWebCodecsRecording / teardownCropper 时置空；MediaRecorder 路径保持 null */
let cropFrameSink = null;

/** WebCodecs H264 硬编录制会话（画质根方案）：
 *  本环境 MediaRecorder 的 MP4 体检失败，只能走 VP8 软编——实时 deadline 下
 *  算法质量天花板低，码率给足仍发糊。WebCodecs 直连硬件 H264 编码器：
 *  - 画质：同码率下显著优于 VP8 软编（GPU 报告 Video Encode 硬件加速）
 *  - 背压可见：encodeQueueSize 可读，超限丢帧（MediaRecorder 的帧积压不可见，
 *    曾把 GPU 进程撑到 8.9GB 崩溃）
 *  - 流式落盘：muxer 输出直接写 OPFS，录制全程内存零累积（MediaRecorder 收割
 *    方案仍要在 JS 堆攒 5 秒分段）
 *  - 产物 MP4 自带时长/索引，无需 patchWebmDuration
 *  失败一律返回 null / 抛错，start() 回退 MediaRecorder 链路（用户无感降级）。
 *  仅裁剪路径启用（draw 循环是现成的帧源）；全屏路径仍走 MediaRecorder */
let wcSession = null;

async function startWebCodecsRecording(cropper, audioTrack, bitrate) {
  if (typeof VideoEncoder !== "function") return null;
  if (typeof Mp4Muxer === "undefined") return null;
  const canvas = cropper.canvas;
  const width = canvas.width;
  const height = canvas.height;
  if (!width || !height) return null;
  // 编码档位从高到低逐档探测，第一档 supported 即用。六轮实录定案（本机
  // Win11 + 无 VP9 硬编）：Chrome 对所有码率控制参数全部无视（H264 VBR 20M→
  // 0.65M、H264 CBR 8M→0.66M、VP9 quantizer/CBR→2.03M、MediaRecorder VP9 8M→
  // 0.79M），输出码率全由 Chrome 按内容自裁量 → 优化目标改为「选自裁量最
  // 大方的 codec」：VP9 ~2Mbps（p25 帧 4.2KB）远优于 H264 0.66M（p25 82B）。
  // 1) VP9 + quantizer 14 / 2) VP9 + CBR 6M：值正确映射的实现上质量/体积比
  //    更优（quality 延迟档开 RD 决策）；本机无论哪个档均被自裁量到 ~2M
  // 3) High + CBR 8M / 4) High + quantizer 12 / 5) High + 20M / 6) High + 8M /
  // 7) Baseline：仅作 VP9 全拒机器的兜底
  // colorSpace 必传：mp4-muxer 写 vpcC 要求 decoderConfig 带 colorSpace，
  // Chrome 的 VP9 输出不保证自带，configure 显式声明让 meta 稳定携带
  // 每档探测必须 try-catch：老 Chrome 不认识 quantizer 枚举时 isConfigSupported
  // 会直接 throw（WebIDL 枚举校验失败），不接住会中断整条 WebCodecs 路径
  // latencyMode 必须是 "realtime"：硬件 H264 编码器是实时流水线，"quality" 档
  // （为软编设计）会被 isConfigSupported 直接拒绝——曾因 quality 档全拒、
  // 静默回退 VP8 软编（用户产物变 WebM 且模糊）
  const baseCfg = {
    width,
    height,
    bitrate,
    framerate: 30,
    latencyMode: "realtime",
  };
  // avc 输出格式只声明在 H264 档（输出 avcC 描述符，mp4 封装必需）；
  // VP9 档不携带无关字段，避免实现对未知组合校验 throw
  const avcFmt = { avc: { format: "avc" } };
  // VP9 档构造器：level 仅作 codec string 解析门槛（实测 level "00" 全拒、
  // "10" 可用），isConfigSupported 会按实际宽高校验
  const vp9 = (level, cfg) => ({
    ...baseCfg,
    codec: `vp09.00.${level}.08`, // profile 0 / 8bit
    ...cfg,
    colorSpace: { primaries: "bt709", transfer: "bt709", matrix: "bt709", fullRange: false },
  });
  const candidates = [
    // VP9 恒定质量/码率（本机实测最优画质：Chrome 对 VP9 软编自裁量 ~2Mbps，
    // 显著优于 H264 自裁量的 0.66M——六轮实录定案，详见函数头注释）
    vp9("10", { latencyMode: "quality", bitrateMode: "quantizer", quantizer: 14 }),
    vp9("10", { bitrateMode: "quantizer", quantizer: 14 }),
    vp9("10", { latencyMode: "quality", bitrateMode: "constant", bitrate: 6000000 }),
    vp9("31", { latencyMode: "quality", bitrateMode: "constant", bitrate: 6000000 }), // 大选区 level 兜底
    vp9("10", { bitrateMode: "constant", bitrate: 6000000 }),
    // H264 档：本机自裁量 0.66M 帧质量崩坏（p25 82B），仅在 VP9 全拒的机器兜底
    { ...baseCfg, ...avcFmt, codec: "avc1.64002a", bitrateMode: "constant", bitrate: 8000000 },
    { ...baseCfg, ...avcFmt, codec: "avc1.64002a", bitrateMode: "quantizer", quantizer: 12 },
    { ...baseCfg, ...avcFmt, codec: "avc1.64002a", bitrate: 20000000 },
    { ...baseCfg, ...avcFmt, codec: "avc1.64002a", bitrate: 12000000 },
    { ...baseCfg, ...avcFmt, codec: "avc1.64002a" }, // 原码率（8M 下限，实测可用保底档）
    { ...baseCfg, ...avcFmt, codec: "avc1.42002a" },
  ];
  let videoCfg = null;
  for (const cfg of candidates) {
    try {
      const probe = await VideoEncoder.isConfigSupported(cfg);
      if (probe && probe.supported) {
        videoCfg = cfg;
        break;
      }
      console.warn(
        "ToolSide WebCodecs: 编码档位被拒",
        cfg.codec,
        cfg.bitrateMode || `vbr@${cfg.bitrate}`,
      );
    } catch (e) {
      console.warn(
        "ToolSide WebCodecs: 编码档位探测异常（视为拒绝）",
        cfg.codec,
        cfg.bitrateMode || `vbr@${cfg.bitrate}`,
        e,
      );
    }
  }
  if (!videoCfg) {
    // isConfigSupported 的判定受硬件编码器资源态影响（实测同一配置先成功后拒绝，
    // NVENC/QSV 的 session 占用/GPU 电源态都会让它保守误报）。全拒时不再放弃，
    // 直接 configure 实测：成功则照常录制；真失败由 error 回调把 Chrome 的
    // 具体原因写进 failed，停止时随元数据返回给面板（优于静默回退）
    console.warn(
      "ToolSide WebCodecs: isConfigSupported 全拒，直接 configure 实测 High+原码率",
    );
    videoCfg = { ...baseCfg, ...avcFmt, codec: "avc1.64002a" };
  }
  console.info(
    "ToolSide WebCodecs: 实际使用档位",
    videoCfg.codec,
    videoCfg.bitrateMode || `vbr@${videoCfg.bitrate}`,
    videoCfg.latencyMode,
    videoCfg.bitrateMode === "quantizer" ? `q=${videoCfg.quantizer}` : `b=${videoCfg.bitrate}`,
  );

  // 音频：opus-in-mp4（Chrome 播放器支持；编码配置按轨道实际元数据）
  let audioCfg = null;
  if (audioTrack && typeof AudioEncoder === "function") {
    const as = audioTrack.getSettings();
    audioCfg = {
      codec: "opus",
      sampleRate: as.sampleRate || 48000,
      numberOfChannels: Math.min(2, as.channelCount || 2),
      bitrate: 128000,
    };
    const asup = await AudioEncoder.isConfigSupported(audioCfg);
    if (!asup || !asup.supported) audioCfg = null;
  }

  // OPFS 流式落盘：编码产出即写盘
  const fileName = `${REC_FILE_PREFIX}${Date.now()}.mp4`;
  const root = await opfsRoot();
  const fh = await root.getFileHandle(fileName, { create: true });
  const writable = await fh.createWritable();
  const muxer = new Mp4Muxer.Muxer({
    target: new Mp4Muxer.FileSystemWritableFileStreamTarget(writable),
    video: {
      // 按实际选中档位封装：VP9 写 vpcC（依赖 configure 声明的 colorSpace），
      // 其余写 avcC，与 VideoEncoder 输出的 meta 一致
      codec: videoCfg.codec.startsWith("vp09") ? "vp9" : "avc",
      width,
      height,
      frameRate: 30,
    },
    ...(audioCfg
      ? { audio: { codec: "opus", numberOfChannels: audioCfg.numberOfChannels, sampleRate: audioCfg.sampleRate } }
      : {}),
    fastStart: false, // 不做内存级 moov 前置，流式写
    // 帧时间戳基于 performance.now（文档年龄），首帧非 0：offset 让每条轨道的
    // 首个 chunk 平移到 0（视频手动算的 ts 和音频 AudioData 自带 ts 一并处理）
    firstTimestampBehavior: "offset",
  });

  let failed = "";
  const s = {
    muxer,
    writable,
    file: fileName,
    frameCount: 0,
    dropped: 0,
    paused: false,
    stopped: false,
    audioReader: null,
    failed: () => failed,
  };

  const videoEncoder = new VideoEncoder({
    output: (chunk, meta) => {
      try {
        muxer.addVideoChunk(chunk, meta);
      } catch (e) {
        failed = `mp4 封装异常：${e && e.message}`;
      }
    },
    error: (e) => {
      failed = `视频编码器异常：${e && e.message}`;
    },
  });
  videoEncoder.configure(videoCfg);

  let audioEncoder = null;
  if (audioCfg) {
    audioEncoder = new AudioEncoder({
      output: (chunk, meta) => {
        try {
          muxer.addAudioChunk(chunk, meta);
        } catch (e) {
          failed = `mp4 封装异常：${e && e.message}`;
        }
      },
      error: (e) => {
        failed = `音频编码器异常：${e && e.message}`;
      },
    });
    audioEncoder.configure(audioCfg);
  }
  s.videoEncoder = videoEncoder;
  s.audioEncoder = audioEncoder;

  // 音频帧循环：必须持续读（不读会让音频帧在管线积压），暂停/停止时读了即弃
  if (audioEncoder && audioTrack && typeof MediaStreamTrackProcessor === "function") {
    try {
      const processor = new MediaStreamTrackProcessor({ track: audioTrack });
      s.audioReader = processor.readable.getReader();
      (async () => {
        try {
          for (;;) {
            const { value: data, done } = await s.audioReader.read();
            if (done || !data) break;
            if (s.stopped || s.paused || failed) {
              data.close();
              continue;
            }
            s.audioEncoder.encode(data);
            data.close();
          }
        } catch (e) {}
      })();
    } catch (e) {
      // 音频循环起不来：降级为纯画面 MP4（音频元数据已写进 muxer 会不匹配——
      // 直接放弃音频：重建 muxer 太重，回退 MediaRecorder 更稳）
      return null;
    }
  }

  // 帧钩子：draw 循环每画一帧就地编码；编码背压超限丢帧（可观测，不会积压）
  cropFrameSink = () => {
    if (!wcSession || wcSession !== s || failed || s.stopped || s.paused) return;
    if (s.videoEncoder.encodeQueueSize > 3) {
      s.dropped++;
      return;
    }
    // 时间戳微秒（performance.now 基准）。暂停期间无帧产出 → PTS 留间隙：
    // 播放时间线不含暂停时长（与 MediaRecorder pause 行为一致），音视频同基准同 gap
    const ts = Math.round(performance.now() * 1000);
    let frame;
    try {
      frame = new VideoFrame(canvas, { timestamp: ts });
    } catch (e) {
      return;
    }
    s.videoEncoder.encode(frame, { keyFrame: s.frameCount % 30 === 0 }); // 1s 一关键帧：
    // 屏幕内容的 P 帧会随时间累积模糊感（尤其动态游戏画面），缩短 GOP 让画面
    // 每秒被 I 帧完整刷新一次，代价是码率略升——画质优先
    frame.close();
    s.frameCount++;
  };

  wcSession = s;
  return s;
}

/** 结束 WebCodecs 录制：flush 双编码器 → finalize 封装 → 关闭落盘句柄。
 *  返回与 MediaRecorder 分支一致的元数据结构（size 从落盘文件实测） */
async function stopWebCodecsRecording() {
  const s = wcSession;
  wcSession = null;
  cropFrameSink = null;
  if (!s) return null;
  s.stopped = true;
  try {
    await s.audioReader?.cancel();
  } catch (e) {}
  let failed = s.failed();
  try {
    await s.videoEncoder.flush();
    s.videoEncoder.close();
  } catch (e) {
    failed = failed || `视频编码器 flush 失败：${e && e.message}`;
  }
  if (s.audioEncoder) {
    try {
      await s.audioEncoder.flush();
      s.audioEncoder.close();
    } catch (e) {
      failed = failed || `音频编码器 flush 失败：${e && e.message}`;
    }
  }
  try {
    s.muxer.finalize();
    await s.writable.close();
  } catch (e) {
    failed = failed || `mp4 落盘失败：${e && e.message}`;
  }
  if (failed) return { ok: false, error: failed, file: s.file, mime: "video/mp4" };
  let size = 0;
  try {
    const root = await opfsRoot();
    size = (await (await root.getFileHandle(s.file)).getFile()).size;
  } catch (e) {}
  return { ok: true, file: s.file, mime: "video/mp4", size, at: Date.now() };
}

/** 启动裁剪帧绘制循环。固定 30fps 定时重绘是 GPU 崩溃元凶：tabCapture 在画面静止时
 *  不产新帧，但定时器仍每 33ms 做一次 GPU 纹理搬运，GPU/编码长期满载 → GPU 进程
 *  崩溃或驱动复位（表现即录制中浏览器闪黑屏）。
 *  因此优先 rVFC 帧驱动：视频出新帧才重绘，静止期 GPU 零负载；rVFC 跟随媒体帧
 *  而非渲染循环，不可见文档同样触发。注意不能用「currentTime 推进而回调没来」做
 *  异常判据——画面静止时 currentTime 照样推进、rVFC 不触发是正常行为，会误判。
 *  改用 2s 探测窗：并行跑低频保底绘制（canvas 不断帧，编码器体检不空转）并统计
 *  rVFC 实际触发次数，窗口结束后按结果决策。误判方向只会是「退回定时器」，安全。
 *
 *  帧率上限：WebCodecs 主路径 30fps（33ms 节流；硬编算力有富余，软编有
 *  encodeQueueSize 背压丢帧护着，产帧率超编不积压）；回退 MediaRecorder 软编
 *  路径降到 20fps（drawMinInterval 改回 50 + 轨道约束），软编 30fps 会积压崩溃。
 *  产帧率 ≤ 编码器消化率。 */
let drawMinInterval = 33; // ~30fps 主路径；回退软编时改 50

function startDrawLoop() {
  stopDrawLoop();
  const video = cropVideo;
  if (!video || typeof video.requestVideoFrameCallback !== "function") {
    cropTimer = setInterval(cropDraw, drawMinInterval);
    return;
  }
  let rafCount = 0;
  let lastDraw = 0;
  const loop = () => {
    // 先续链再节流：draw 抛异常也不会断掉帧驱动
    cropRafId = video.requestVideoFrameCallback(loop);
    rafCount++;
    const now = performance.now();
    if (now - lastDraw < drawMinInterval) return; // 超出帧率预算的帧直接丢弃
    lastDraw = now;
    cropDraw();
  };
  cropRafId = video.requestVideoFrameCallback(loop);
  // 探测期保底绘制频率 = 正式节流频率：编码器体检窗口只有 400ms，
  // 保底太稀（如 500ms）会让窗口内 0 帧产出、全部候选误判失败；与正式
  // 录制消费率一致，也不会造成 GPU 侧帧积压
  cropTimer = setInterval(cropDraw, drawMinInterval);
  cropWatchdog = setTimeout(() => {
    clearInterval(cropTimer);
    cropTimer = null;
    if (rafCount === 0) {
      // 2s 内 rVFC 一次都没触发：该环境把它耦合进渲染循环，回退定时器驱动
      try {
        video.cancelVideoFrameCallback(cropRafId);
      } catch (e) {}
      cropRafId = 0;
      cropTimer = setInterval(cropDraw, drawMinInterval);
    }
    // rVFC 可用：已是纯帧驱动，静止期零重绘零 GPU 负载，无需再干预
  }, 2000);
}

function stopDrawLoop() {
  if (cropWatchdog) {
    clearTimeout(cropWatchdog);
    cropWatchdog = null;
  }
  if (cropTimer) {
    clearInterval(cropTimer);
    cropTimer = null;
  }
  const video = cropVideo;
  if (cropRafId && video && typeof video.cancelVideoFrameCallback === "function") {
    try {
      video.cancelVideoFrameCallback(cropRafId);
    } catch (e) {}
  }
  cropRafId = 0;
}

function teardownCropper() {
  stopDrawLoop();
  cropFrameSink = null; // WebCodecs 路径的帧钩子一并断开
  cropDraw = null;
  if (cropVideo) {
    cropVideo.srcObject = null;
    cropVideo = null;
  }
}

async function start(streamId, cropRect) {
  if (recorder) throw new Error("已在录制中");
  // 新录制开始即清掉上次未收割的旧成品（取走即清语义，宁丢旧不积压）
  await cleanOldRecordings();
  recordError = null;
  cropped = false;
  // tab 音频轨道在没有声音的页面上可能获取失败：先带音频试，失败后向背景
  // 重申新 streamId 再退化为纯画面重试（反馈 #1；旧凭证已被首次请求消耗）
  let stream;
  try {
    stream = await grabStream(streamId, true);
  } catch (e) {
    const sid = await newStreamId();
    if (!sid) throw e;
    stream = await grabStream(sid, false);
  }

  const videoTrack = stream.getVideoTracks()[0];
  const audioTrack = stream.getAudioTracks()[0] || null;
  liveTracks = [videoTrack, audioTrack].filter(Boolean);

  // 捕获到的标签页声音继续外放（Chrome 官方 offscreen 录制示例的做法）；
  // Audio 元素在 offscreen 里 play() 会被自动播放策略拒绝，静默/未播放的
  // 音频元素曾连带 MediaRecorder 产出 0 字节流（crbug 1136404 一族）
  if (audioTrack) {
    try {
      audioCtx = new AudioContext();
      audioCtx.createMediaStreamSource(new MediaStream([audioTrack])).connect(audioCtx.destination);
      audioCtx.resume().catch(() => {});
    } catch (e) {
      audioCtx = null;
    }
  }

  // 区域录屏：canvas 逐帧裁剪出新的视频轨（固定视口选区，不随页面滚动）
  let recordVideoTrack = videoTrack;
  let cropper = null;
  if (cropRect) {
    cropped = true;
    // 把帧尺寸约束到视口物理尺寸：Chrome 默认可能把捕获映射进 1920×1080 等标准帧
    // （等比缩放 + letterbox 居中），两轴换算比不一致会让选区错位；
    // 对齐后帧与视口 1:1 对应（实测约束生效，帧 1534×937 = 视口），draw 按 dpr 换算即可
    if (cropRect.viewW && cropRect.viewH) {
      try {
        await videoTrack.applyConstraints({
          width: Math.round(cropRect.viewW * (cropRect.dpr || 1)),
          height: Math.round(cropRect.viewH * (cropRect.dpr || 1)),
        });
      } catch (e) {}
    }
    cropper = buildCropper(videoTrack, cropRect);
    await cropper.ready; // 首帧画出后再交给编码器体检/录制，避免空白 canvas 全挂
    recordVideoTrack = cropper.track;
  }

  // 裁剪路径优先 WebCodecs（画质根方案，见 startWebCodecsRecording 注释）；
  // 初始化失败/环境不支持则回退 MediaRecorder 链路，行为与旧版完全一致。
  // 2026-09 实测记录：MediaRecorder VP9 + 8M 的 videoBitsPerSecond 同样被无视
  // （实录 ≈0.79Mbps，且软编消化不良画质比 WebCodecs 更崩），故主路径回退
  // WebCodecs、兜底链维持 VP8 优先不动
  if (cropper) {
    const cw = cropper.canvas.width;
    const ch = cropper.canvas.height;
    // 屏幕内容（高细节 UI 文字 + 动态游戏画面）码率需求高于相机内容；
    // 8Mbps 下限是 30fps 高清档的保底，面积大时按 4bit/px 提升，15M 封顶
    const bitrate = Math.round(Math.min(15000000, Math.max(8000000, cw * ch * 4)));
    try {
      if (await startWebCodecsRecording(cropper, audioTrack, bitrate)) {
        recordStartedAt = Date.now();
        armAutoStop();
        return;
      }
    } catch (e) {
      console.warn("ToolSide WebCodecs init failed, fallback to MediaRecorder:", e);
    }
    console.warn("ToolSide WebCodecs 路径未启用，回退 MediaRecorder 软编（画质受限）");
    // 回退 MediaRecorder 软编：产帧率必须降回 20fps（节流 + 轨道约束同步），
    // 否则 VP8 30fps 消化不动，帧积压会把 GPU 进程再次撑爆
    drawMinInterval = 50;
    if (cropTimer) {
      clearInterval(cropTimer);
      cropTimer = setInterval(cropDraw, drawMinInterval);
    }
    try {
      await cropper.track.applyConstraints({ frameRate: 20 });
    } catch (e) {}
  }

  const withAudioStream = new MediaStream(
    audioTrack ? [recordVideoTrack, audioTrack] : [recordVideoTrack],
  );
  const videoOnlyStream = new MediaStream([recordVideoTrack]);

  // 编码器体检：裁剪路径直接在裁剪后的流上测，与正式录制完全一致
  chunks = [];
  const pick = await pickMime(withAudioStream, videoOnlyStream, !!audioTrack);

  // 码率按编码目标（选区 canvas 物理像素）自适应：VP8 压缩效率低，屏幕内容
  // 需要 ~4 bit/px 才不发糊（选区小像素少，按面积给码率才不会贴下限导致模糊）；
  // 1080p 全屏 ≈ 8.3Mbps、小选区由 4Mbps 下限兜底，上限 10Mbps 控制文件体积。
  // canvas 像素换算与 buildCropper 的 dprScale² 一致（min²=正数域下等价）
  const vs = recordVideoTrack.getSettings();
  const canvasPx = cropRect
    ? cropRect.w *
      cropRect.h *
      Math.min((cropRect.dpr || 1) ** 2, 2100000 / Math.max(1, cropRect.w * cropRect.h))
    : (vs.width || 1280) * (vs.height || 720);
  const options = {
    videoBitsPerSecond: Math.round(Math.min(10000000, Math.max(4000000, canvasPx * 4))),
    audioBitsPerSecond: 128000,
  };
  if (pick.mime) options.mimeType = pick.mime;
  recorder = new MediaRecorder(pick.withAudio ? withAudioStream : videoOnlyStream, options);
  recorder.ondataavailable = (e) => {
    if (e.data && e.data.size > 0) chunks.push(e.data);
  };
  recorder.onerror = (e) => {
    recordError = String((e && e.error && e.error.message) || e.error || "编码器异常");
    console.warn("ToolSide recorder error:", recordError);
  };
  // 分段策略按容器区分：
  // - WebM 用标准 timeslice（recorder.start(5000)）：每段是增量 Cluster，天然衔接，
  //   编码产出每 5s 落到 chunks（JS 堆，可控），长录不在 recorder 内部无界堆积；
  // - MP4 必须一次性 start()：Chrome 的 MP4 muxer 任何形式的中途分段都互不衔接，
  //   产物只有十几字节残片（时长 0:00）。实测「无 timeslice + requestData」在
  //   Chrome 上还会产出全量流（每段都是从头开始的完整文件），多段拼接后中间夹
  //   EBML 头，播放器解析到第一个 EBML 结束就停 → 时长 0:00、画面无内容
  if ((pick.mime || "").includes("webm")) {
    recorder.start(5000);
  } else {
    recorder.start();
  }
  recordStartedAt = Date.now();
  armAutoStop();
}

/** 到点自动停止（MAX_MS 上限）：offscreen 主动推结果给 background（此时没有
 *  等待回执的请求；失败结果也推送，让面板能看到具体失败原因）。
 *  WebCodecs 与 MediaRecorder 两条路径共用 */
function armAutoStop() {
  setKeepalive(true);
  if (maxTimer) clearTimeout(maxTimer);
  maxTimer = setTimeout(() => {
    stop()
      .then((r) => {
        if (r) {
          chrome.runtime
            .sendMessage({ type: "toolside:offscreen-recording", recording: r })
            .catch(() => {});
        }
      })
      .catch(() => {});
  }, MAX_MS);
}

/** 读 EBML 变长整数。keepMarker=true 用于元素 ID（保留首位定位比特），
 *  false 用于 Size（去掉定位比特）；Size 全 1 表示未知大小，返回 -1。
 *  返回 { value, len }，数据不足或非法时返回 null */
function readVint(buf, off, keepMarker) {
  if (off >= buf.length) return null;
  const first = buf[off];
  if (first === 0) return null; // 首字节 0 意味着宽度超过 8 字节，非法
  let len = 1;
  let mask = 0x80;
  while (!(first & mask)) {
    len++;
    mask >>= 1;
  }
  if (len > 8 || off + len > buf.length) return null;
  let value = keepMarker ? first : first & (mask - 1);
  for (let i = 1; i < len; i++) value = value * 256 + buf[off + i];
  return { value, len };
}

/** 按指定字节数把非负整数写为 EBML 变长 Size（带定位比特）。超位数范围返回 false */
function writeVint(buf, off, value, len) {
  const max = Math.pow(2, 7 * len) - 1;
  if (value < 0 || value > max) return false;
  let v = value;
  for (let i = len - 1; i >= 1; i--) {
    buf[off + i] = v & 0xff;
    v = Math.floor(v / 256);
  }
  buf[off] = (0x100 >> len) | v;
  return true;
}

/** 判断 value 能否用 len 字节变长 Size 编码 */
function vintFits(value, len) {
  return value >= 0 && len > 0 && len <= 8 && value <= Math.pow(2, 7 * len) - 1;
}

/** 把非负整数编码为 len 字节变长 Size 的 Blob（用于零拷贝组装替换段） */
function encodeVintBlob(value, len) {
  const bytes = new Uint8Array(len);
  writeVint(bytes, 0, value, len);
  return new Blob([bytes]);
}

/** Chrome 的 WebM 产物缺 Duration（播放器一律显示 0:00、无法拖动进度）。
 *  曾用 vendor/webm-duration-fix 修补，但它对 timeslice 多 Cluster 文件做
 *  完整重解析+重组，实测会丢掉画面数据（产物无内容）——弃用。
 *  这里改为「纯插入式」补丁：只原地改写或最小化插入字节，绝不重组文件，
 *  从机制上杜绝丢数据；任何解析失败/结构不符一律原样返回（可播，仅时长缺）。
 *  性能：EBML 头部（Segment/Info/Duration 定位所需）只读前 64KB；成品文件
 *  全程用 Blob slice 引用组合，不在主线程做大内存拷贝（90MB 级 memcpy 会
 *  让停止录制后的面板卡住数秒）。
 *  结构：顶层找 Segment(0x18538067) → 段内第一个 Cluster 前找 Info(0x1549A966)
 *  → Info 内找 Duration(0x4489)：存在则原位替换其 float 值；不存在则在 Info
 *  payload 末尾插入该元素（10 字节：ID 2 + size 1 + float32），并同步改写
 *  Info/Segment 的 size 字段 */
async function patchWebmDuration(blob, durationMs) {
  try {
    // 只读头部 64KB：正常产物中 EBML 头 + Segment 头 + Info 总共不到 1KB
    const head = new Uint8Array(await blob.slice(0, 65536).arrayBuffer());
    const scanLen = head.length;
    // 1) 顶层找 Segment
    let off = 0;
    let seg = null;
    while (off < scanLen) {
      const idV = readVint(head, off, true);
      if (!idV) return blob;
      const sizeV = readVint(head, off + idV.len, false);
      if (!sizeV) return blob;
      const dataOff = off + idV.len + sizeV.len;
      if (idV.value === 0x18538067) {
        seg = { dataOff, size: sizeV.value, sizeOff: off + idV.len, sizeLen: sizeV.len };
        break;
      }
      if (sizeV.value === -1) return blob; // 非目标元素未知大小，无法继续扫描
      off = dataOff + sizeV.value;
    }
    if (!seg) return blob;
    // 2) Segment 内、第一个 Cluster 之前找 Info
    const segEnd = seg.size === -1 ? scanLen : Math.min(seg.dataOff + seg.size, scanLen);
    let p = seg.dataOff;
    let info = null;
    while (p < segEnd) {
      const idV = readVint(head, p, true);
      if (!idV) return blob;
      const sizeV = readVint(head, p + idV.len, false);
      if (!sizeV) return blob;
      const dataOff = p + idV.len + sizeV.len;
      if (idV.value === 0x1f43b675) break; // 已到 Cluster，Info 不存在
      if (idV.value === 0x1549a966) {
        info = { size: sizeV.value, sizeOff: p + idV.len, sizeLen: sizeV.len, dataOff };
        break;
      }
      if (sizeV.value === -1) return blob;
      p = dataOff + sizeV.value;
    }
    if (!info || info.size === -1) return blob;
    const infoEnd = Math.min(info.dataOff + info.size, scanLen);
    // 3) Info 内找 Duration
    let q = info.dataOff;
    let dur = null;
    while (q < infoEnd) {
      const idV = readVint(head, q, true);
      if (!idV) break;
      const sizeV = readVint(head, q + idV.len, false);
      if (!sizeV) break;
      const dataOff = q + idV.len + sizeV.len;
      if (idV.value === 0x4489) {
        dur = { dataOff, size: sizeV.value };
        break;
      }
      if (sizeV.value === -1) break;
      q = dataOff + sizeV.value;
    }
    // 3a) Duration 已存在：原位替换 float 值（EBML Duration 单位毫秒、大端）
    if (dur) {
      const floatLen = dur.size === 4 || dur.size === 8 ? dur.size : 0;
      if (!floatLen) return blob; // 非常规宽度，不动
      const dv = new DataView(new ArrayBuffer(floatLen));
      if (floatLen === 4) dv.setFloat32(0, durationMs);
      else dv.setFloat64(0, durationMs);
      const floatBlob = new Blob([dv.buffer]);
      return new Blob(
        [blob.slice(0, dur.dataOff), floatBlob, blob.slice(dur.dataOff + floatLen)],
        { type: blob.type },
      );
    }
    // 3b) Duration 不存在：Info payload 末尾插入 10 字节
    //     （ID 0x4489 两字节 + size 0x84 一字节 + float32 毫秒）
    const INS = 10;
    const insert = new Uint8Array(INS);
    insert[0] = 0x44;
    insert[1] = 0x89;
    insert[2] = 0x84;
    new DataView(insert.buffer).setFloat32(3, durationMs);
    // 4) size 字段新值必须能用原位数编码，否则放弃补丁
    if (!vintFits(info.size + INS, info.sizeLen)) return blob;
    if (seg.size !== -1 && !vintFits(seg.size + INS, seg.sizeLen)) return blob;
    // 5) 零拷贝组装：原文件按 patch 点切段 + 插入段，拼接延迟到写盘时由 IO 层完成
    const at = info.dataOff + info.size;
    const parts = [];
    let cur = 0;
    if (seg.size !== -1) {
      parts.push(blob.slice(cur, seg.sizeOff));
      parts.push(encodeVintBlob(seg.size + INS, seg.sizeLen));
      cur = seg.sizeOff + seg.sizeLen;
    }
    parts.push(blob.slice(cur, info.sizeOff));
    parts.push(encodeVintBlob(info.size + INS, info.sizeLen));
    parts.push(blob.slice(info.sizeOff + info.sizeLen, at));
    parts.push(new Blob([insert]));
    parts.push(blob.slice(at));
    return new Blob(parts, { type: blob.type });
  } catch (e) {
    console.warn("ToolSide webm duration patch failed:", e);
    return blob;
  }
}

/** 容器魔数校验：MP4 必须以 size+"ftyp" 开头、WebM 必须以 EBML 头 0x1A45DFA3 开头，
 *  且 WebM 前 4KB 内必须出现 Cluster（0x1F43B675）——空壳产物只有容器头没有帧数据，
 *  前几 KB 必有 Cluster 的正常产物则通过，防止把无画面的空壳当正常文件交给用户 */
async function looksLikeRecording(blob, mime) {
  const head = new Uint8Array(await blob.slice(0, 12).arrayBuffer());
  if (mime.includes("mp4"))
    return head[4] === 0x66 && head[5] === 0x74 && head[6] === 0x79 && head[7] === 0x70; // "ftyp"
  if (!(head[0] === 0x1a && head[1] === 0x45 && head[2] === 0xdf && head[3] === 0xa3))
    return false;
  const probe = new Uint8Array(await blob.slice(0, 4096).arrayBuffer());
  for (let i = 0; i + 4 <= probe.length; i++) {
    if (
      probe[i] === 0x1f &&
      probe[i + 1] === 0x43 &&
      probe[i + 2] === 0xb6 &&
      probe[i + 3] === 0x75
    )
      return true; // Cluster
  }
  return false;
}

async function stop() {
  if (maxTimer) {
    clearTimeout(maxTimer);
    maxTimer = null;
  }
  setKeepalive(false);

  // WebCodecs 分支：cropper 的 teardown 与 MediaRecorder 分支一致
  if (wcSession) {
    for (const track of liveTracks) track.stop(); // 先解除捕获（见下说明）
    liveTracks = [];
    teardownCropper();
    if (audioCtx) {
      try {
        await audioCtx.close();
      } catch (e) {}
      audioCtx = null;
    }
    const meta = await stopWebCodecsRecording();
    if (!meta) return { ok: false, error: "未在录制" };
    if (!meta.ok) return meta;
    return { ...meta, cropped };
  }

  const rec = recorder;
  recorder = null;
  if (!rec) return { ok: false, error: "未在录制" };

  const done = new Promise((resolve) => {
    rec.onstop = resolve;
  });
  if (rec.state !== "inactive") rec.stop();
  await done;

  // 解除标签页捕获必须放在所有清理的最前：tabCapture 越早结束，被录页面越早
  // 脱离捕获模式恢复正常渲染（否则页面视频在「生成视频」的几秒内持续被管线
  // teardown 拖住）。音频路由切换 / GPU 资源销毁是 Chrome 固有开销，无法根除，
  // 但数据已 flush 完毕，这里晚做无益、早做有益
  for (const track of liveTracks) track.stop();
  liveTracks = [];
  teardownCropper();
  if (audioCtx) {
    try {
      await audioCtx.close();
    } catch (e) {}
    audioCtx = null;
  }

  const mime = rec.mimeType || "video/webm";
  // 分段完整性自检：正常 timeslice 分段中，第 2 段起以 Cluster 元素（0x1F43B675）
  // 或其它子元素开头；若某段以 EBML 头（0x1A45DFA3）开头，说明该段是「从头开始的
  // 完整文件」而非增量（Chrome 的分段异常行为），多段拼接会在中间夹 EBML 头导致
  // 播放器解析到第一段结束就停（时长 0:00、画面无内容）。此时只保留最后一段——
  // 它覆盖了完整的录制时间线
  if (mime.includes("webm") && chunks.length > 1) {
    const head = new Uint8Array(await chunks[1].slice(0, 4).arrayBuffer());
    if (head[0] === 0x1a && head[1] === 0x45 && head[2] === 0xdf && head[3] === 0xa3) {
      console.warn("ToolSide: 检测到分段为全量流而非增量，仅保留最后一段");
      chunks = [chunks[chunks.length - 1]];
    }
  }
  let blob = new Blob(chunks, { type: mime });
  const err = recordError;
  chunks = [];
  recordError = null;
  // 与 probeMime 的 2000 字节体检门槛一致：更小的产物只可能是空壳容器；
  // 报错带实际字节数，便于从截图直接判断编码器状态
  if (blob.size < 2000)
    return {
      ok: false,
      error:
        err ||
        `录制内容过短（仅 ${blob.size} 字节）：编码器未产出有效画面，请稍候几秒再停止`,
    };
  if (mime.includes("webm")) {
    // Duration 用实际录制时长换算写入；补丁失败/结构不符时返回原样（可播，仅时长缺）
    const durationMs = recordStartedAt ? Date.now() - recordStartedAt : 0;
    blob = await patchWebmDuration(blob, durationMs);
  }
  recordStartedAt = 0;
  if (!(await looksLikeRecording(blob, mime)))
    return { ok: false, error: err || "编码器输出损坏（容器头异常），请重试" };
  // 成品落盘 OPFS，消息只回传文件名元数据：以前这里转 base64 过消息通道，
  // 2 分半的录制会在内存里滚出约 1GB 副本直接把渲染进程压崩
  const size = blob.size;
  const file = await saveToOPFS(blob, mime);
  blob = null; // 落盘完成即释放，成品以后只从 OPFS 读
  return { ok: true, file, mime, size, at: Date.now() };
}
